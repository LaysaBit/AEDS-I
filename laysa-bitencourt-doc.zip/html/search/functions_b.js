var searchData=
[
  ['sendingmsg_103',['sendingMsg',['../mensagem_8h.html#ab6a2c5fada41613befbc55f2d69a891e',1,'mensagem.c']]],
  ['setting_104',['setting',['../settings_8h.html#af0f5997f4b8d4cb6f3747c7a077059a9',1,'settings.c']]],
  ['showdm_105',['showDM',['../mensagem_8h.html#a2182b40056f65c90b611a2d078c968a9',1,'mensagem.c']]],
  ['showfriends_106',['showFriends',['../amigos_8h.html#ac0f81a25f40f798b1b8b82121dcad2f6',1,'amigos.c']]],
  ['showgroups_107',['showGroups',['../grupos_8h.html#a7e02612007a7ba45c7f7907611137dd4',1,'grupos.c']]],
  ['showintegrantes_108',['showIntegrantes',['../grupos_8h.html#a090c20772b2b6ea8132646a6726ad4c8',1,'grupos.c']]],
  ['showprofile_109',['showProfile',['../profile_8h.html#a8bb387bdbb1fe81a32970eb5beba0821',1,'profile.c']]],
  ['showusers_110',['showUsers',['../amigos_8h.html#a0d396b25ba27a6d91e98db6e834f6384',1,'amigos.c']]]
];
