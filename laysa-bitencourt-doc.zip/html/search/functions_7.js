var searchData=
[
  ['newgroup_96',['newGroup',['../grupos_8h.html#a337d0876694a7fe6a9f45477308ed30e',1,'grupos.c']]],
  ['nodegroups_97',['nodeGroups',['../grupos_8h.html#a79233ae51a8d45380b47a4c9dd083d81',1,'grupos.c']]],
  ['nofriends_98',['noFriends',['../amigos_8h.html#a0060fc6966c86912ee5fd2a4957e0056',1,'amigos.c']]],
  ['nogroups_99',['noGroups',['../grupos_8h.html#ac18e9979c0155c6d00d2076e16c235ea',1,'grupos.c']]]
];
