var searchData=
[
  ['initialgroups_21',['initialGroups',['../grupos_8h.html#aff7703fff0a2c4c74b94c37e1435cdb9',1,'grupos.c']]],
  ['initialinsert_22',['initialInsert',['../amigos_8h.html#a2498e7cd68954b19716ef92530da0831',1,'amigos.c']]],
  ['initialinsertuser_23',['initialInsertUser',['../grupos_8h.html#a21c0e8e9fb841202ac045c89931e3088',1,'grupos.c']]],
  ['initusers_24',['initUsers',['../profile_8h.html#a2ea56f6ce382eec8a008001b7bbf0aa4',1,'profile.c']]],
  ['insertandorder_25',['insertAndOrder',['../amigos_8h.html#ac0ac1430e7a477da0028d349633b44d9',1,'amigos.c']]],
  ['insertuser_26',['insertUser',['../grupos_8h.html#a9579bd6843f3377e00c0bebdd4b9586c',1,'grupos.c']]],
  ['integrantes_27',['integrantes',['../structintegrantes.html',1,'']]]
];
