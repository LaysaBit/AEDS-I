var searchData=
[
  ['getint_17',['getInt',['../basicfunc_8h.html#a62b48a5d57e511a4d54bbf667cea8852',1,'basicfunc.c']]],
  ['getstring_18',['getString',['../basicfunc_8h.html#a13c4e1a2bbabebc4954110718b144abd',1,'basicfunc.c']]],
  ['group_19',['group',['../structgroup.html',1,'']]],
  ['grupos_2eh_20',['grupos.h',['../grupos_8h.html',1,'']]]
];
