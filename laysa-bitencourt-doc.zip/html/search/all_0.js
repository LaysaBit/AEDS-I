var searchData=
[
  ['addfriends_0',['addFriends',['../amigos_8h.html#aaeed254ef9220dd1d5bdcf7b3319246f',1,'amigos.c']]],
  ['addusertogroup_1',['addUserToGroup',['../grupos_8h.html#ab4d59515e59645bb786fdea45108708e',1,'grupos.c']]],
  ['amigos_2eh_2',['amigos.h',['../amigos_8h.html',1,'']]],
  ['aretheyfriends_3',['areTheyFriends',['../amigos_8h.html#a7c129dd7d5d8443b156015e5378717da',1,'amigos.c']]]
];
