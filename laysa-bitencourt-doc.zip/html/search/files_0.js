var searchData=
[
  ['amigos_2eh_63',['amigos.h',['../amigos_8h.html',1,'']]]
];
