var searchData=
[
  ['settings_2eh_70',['settings.h',['../settings_8h.html',1,'']]]
];
