var searchData=
[
  ['getint_83',['getInt',['../basicfunc_8h.html#a62b48a5d57e511a4d54bbf667cea8852',1,'basicfunc.c']]],
  ['getstring_84',['getString',['../basicfunc_8h.html#a13c4e1a2bbabebc4954110718b144abd',1,'basicfunc.c']]]
];
