var searchData=
[
  ['tolower_111',['toLower',['../amigos_8h.html#a26af8d85efd3dce9709d8df434e9a173',1,'amigos.c']]]
];
