var searchData=
[
  ['findgroupbyname_12',['findGroupByName',['../grupos_8h.html#a534f74307ed301a56997e6a0d8f45629',1,'grupos.c']]],
  ['finduser_13',['findUser',['../profile_8h.html#a155f601b2e43c2d7cd7d9cdbf479c7e1',1,'profile.c']]],
  ['finduserbyname_14',['findUserByName',['../amigos_8h.html#a6f7b6fb308ee661a80076c4b04de6fb0',1,'amigos.c']]],
  ['freelist_15',['freeList',['../mensagem_8h.html#a92b9367942828cfe69faa3669f94b3e1',1,'mensagem.c']]],
  ['friends_16',['friends',['../structfriends.html',1,'']]]
];
