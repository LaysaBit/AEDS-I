var searchData=
[
  ['cadastro_6',['cadastro',['../structcadastro.html',1,'']]],
  ['createaccount_7',['createAccount',['../profile_8h.html#a93c98a34c95eabd5b6e416bbfd6883ee',1,'profile.c']]],
  ['createboard_8',['createBoard',['../mural_8h.html#a213636a9ecb70aca7a264932d819e7cd',1,'mural.c']]],
  ['createfriends_9',['createFriends',['../amigos_8h.html#a3b88834c6dc96a595c1672a40b184a0b',1,'amigos.c']]],
  ['createstory_10',['createStory',['../mural_8h.html#a0d4477c4f8abc7e17aa885a38f72139c',1,'mural.c']]],
  ['criarintegrantes_11',['criarIntegrantes',['../grupos_8h.html#a964ac429ade92bd06aa2801611d48989',1,'grupos.c']]]
];
