var searchData=
[
  ['friends_59',['friends',['../structfriends.html',1,'']]]
];
