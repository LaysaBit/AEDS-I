var searchData=
[
  ['ordergroups_41',['orderGroups',['../grupos_8h.html#a97a7aac54a54b4b7a267bc12458ae9d2',1,'grupos.c']]]
];
