var searchData=
[
  ['menu_92',['menu',['../menu_8h.html#ad680efed2829b7baeb2ca74889c09577',1,'menu.c']]],
  ['menuconfig_93',['menuConfig',['../settings_8h.html#a4bca1766123ab3063f12cff0b9d32a53',1,'settings.c']]],
  ['middleorend_94',['middleOrEnd',['../amigos_8h.html#a4da6cb64a079670ee9433ce0fd62350b',1,'amigos.c']]],
  ['modifyprofile_95',['modifyProfile',['../profile_8h.html#a24a34db20447fb3928812dff88a8a71c',1,'profile.c']]]
];
