var searchData=
[
  ['basicfunc_2eh_4',['basicfunc.h',['../basicfunc_8h.html',1,'']]],
  ['board_5',['board',['../structboard.html',1,'']]]
];
