var searchData=
[
  ['loginarea_91',['loginArea',['../menu_8h.html#a0aceb282a045bcb8dd4ed0fcd56d8f2c',1,'menu.c']]]
];
